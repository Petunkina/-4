package main

import (
	"fmt"
	"time"
)

func main() {
	const maxRate = 5
	const totalRequests = 15
	const interval = 200 * time.Millisecond
	tick := time.Tick(interval)
	for i := 1; i <= totalRequests; i++ {
		<-tick
		fmt.Printf("Запрос №%d выполнен\n", i)
	}
}
