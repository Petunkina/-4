package main

import (
	"fmt"
	"sync"
)
func worker(jobs <-chan int, results chan<- int, wg *sync.WaitGroup) {
	defer wg.Done()
	for num := range jobs {
		results <- num * num
	}
}
func main() {
	const numWorkers = 3
	const numTasks = 10
	jobs := make(chan int)
	results := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < numWorkers; i++ {
		wg.Add(1)
		go worker(jobs, results, &wg)
	}
	go func() {
		for i := 1; i <= numTasks; i++ {
			jobs <- i
		}
		close(jobs)
	}()
	go func() {
		wg.Wait()
		close(results)
	}()
	for res := range results {
		fmt.Println(res)
	}
}
